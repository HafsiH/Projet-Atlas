import React, { useState, useEffect } from 'react'
import { ChevronDown, Target, Zap, TrendingUp, Users, Mail, FileText, CheckCircle, ArrowRight } from 'lucide-react'

import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('hero')

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'vision', 'phases', 'benefices', 'contact']
      const scrollPosition = window.scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (sectionId) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-md border-b border-gray-200 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold text-gray-900">Projet Atlas</div>
            <div className="hidden md:flex space-x-8">
              {[
                { id: 'vision', label: 'Vision' },
                { id: 'phases', label: 'Phases' },
                { id: 'benefices', label: 'Bénéfices' },
                { id: 'contact', label: 'Contact' }
              ].map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => scrollToSection(id)}
                  className={`text-sm font-medium transition-colors ${
                    activeSection === id ? 'text-green-600' : 'text-gray-600 hover:text-green-600'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="pt-20 pb-16 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Projet <span className="text-green-600">Atlas</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
              Automatisation intelligente des bilans carbone d'entreprise
            </p>
            <p className="text-lg text-gray-500 mb-12 max-w-2xl mx-auto">
              Transformer une obligation réglementaire en levier stratégique de création de valeur
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => scrollToSection('phases')}
                className="bg-green-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
              >
                Découvrir les phases <ArrowRight className="w-5 h-5" />
              </button>
              <a
                href="/hamzahafsi-professional-document.pdf"
                target="_blank"
                className="border border-green-600 text-green-600 px-8 py-4 rounded-lg font-semibold hover:bg-green-50 transition-colors flex items-center justify-center gap-2"
              >
                <FileText className="w-5 h-5" /> Rapport complet
              </a>
            </div>
          </div>
          <div className="mt-16 animate-bounce">
            <ChevronDown className="w-6 h-6 text-gray-400 mx-auto" />
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section id="vision" className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">La Vision</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Révolutionner la comptabilité carbone grâce à l'IA et transformer les processus manuels en écosystème technologique intelligent
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Problématique actuelle</h3>
              <div className="space-y-4">
                {[
                  'Processus manuels longs et coûteux',
                  'Manque de granularité dans l\'analyse',
                  'Difficulté d\'intégration systèmes existants',
                  'Absence d\'outils d\'aide à la décision'
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                    <span className="text-gray-600">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Solution Atlas</h3>
              <div className="space-y-4">
                {[
                  'Automatisation intelligente par IA',
                  'Granularité site/produit/business unit',
                  'APIs natives pour ERP existants',
                  'ROI carbone et gestion des risques'
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-600">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Phases Section */}
      <section id="phases" className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">3 Phases Progressives</h2>
            <p className="text-xl text-gray-600">
              De la validation concept au déploiement stratégique complet
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                phase: 'Phase I',
                title: 'Validation concept',
                duration: '6-8 mois',
                icon: Target,
                color: 'blue',
                technologies: ['Deep Learning v0', 'NLP'],
                livrable: 'Modèle attribution codes NACRE + plateforme web'
              },
              {
                phase: 'Phase II',
                title: 'Version professionnelle',
                duration: '12-15 mois',
                icon: Zap,
                color: 'green',
                technologies: ['LLM', 'Data Visualization'],
                livrable: 'Modèle v1 (2-3x plus performant) + visualisations'
              },
              {
                phase: 'Phase III',
                title: 'Plateforme stratégique',
                duration: '18-24 mois',
                icon: TrendingUp,
                color: 'purple',
                technologies: ['FinTech', 'Risk Management'],
                livrable: 'ROI carbone + outils gestion des risques'
              }
            ].map((phase, index) => {
              const Icon = phase.icon
              return (
                <div key={index} className="bg-white rounded-xl p-8 shadow-sm hover:shadow-md transition-shadow">
                  <div className={`w-12 h-12 bg-${phase.color}-100 rounded-lg flex items-center justify-center mb-6`}>
                    <Icon className={`w-6 h-6 text-${phase.color}-600`} />
                  </div>
                  <div className="mb-4">
                    <div className={`text-sm font-semibold text-${phase.color}-600 mb-1`}>{phase.phase}</div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{phase.title}</h3>
                    <div className="text-sm text-gray-500">{phase.duration}</div>
                  </div>
                  <div className="mb-4">
                    <div className="text-sm font-medium text-gray-700 mb-2">Technologies</div>
                    <div className="flex flex-wrap gap-2">
                      {phase.technologies.map((tech, techIndex) => (
                        <span key={techIndex} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-700 mb-2">Livrable</div>
                    <p className="text-sm text-gray-600">{phase.livrable}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Bénéfices Section */}
      <section id="benefices" className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Bénéfices Clés</h2>
            <p className="text-xl text-gray-600">
              Performance, précision et avantage concurrentiel
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {[
              { label: 'Réduction temps', value: '80-90%', desc: 'vs méthodes manuelles' },
              { label: 'Précision', value: '2-3x', desc: 'supérieure' },
              { label: 'Granularité', value: 'Site/Produit', desc: 'Business unit' },
              { label: 'Intégration', value: 'APIs', desc: 'natives ERP' }
            ].map((metric, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{metric.value}</div>
                <div className="text-lg font-semibold text-gray-900 mb-1">{metric.label}</div>
                <div className="text-sm text-gray-500">{metric.desc}</div>
              </div>
            ))}
          </div>

          <div className="bg-green-50 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Avantage Concurrentiel</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Leadership climatique</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• Position de leader éclairé</li>
                  <li>• Performances opérationnelles supérieures</li>
                  <li>• Maîtrise des risques réglementaires</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Partenaires institutionnels</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• ADEME (validation réglementaire)</li>
                  <li>• INRIA (validation performances)</li>
                  <li>• labo1point5 (recherche)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-6">Prêt à transformer votre stratégie carbone ?</h2>
          <p className="text-xl text-gray-300 mb-12">
            Rejoignez les leaders de la transition climatique
          </p>
          
          <div className="bg-gray-800 rounded-xl p-8 mb-8">
            <h3 className="text-2xl font-bold mb-6">Hamza Hafsi</h3>
            <p className="text-gray-300 mb-6">
              Spécialiste en automatisation de l'empreinte carbone & Développeur de plateformes stratégiques
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="mailto:hamza.hafsi.h@gmail.com"
                className="bg-green-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
              >
                <Mail className="w-5 h-5" /> Prendre contact
              </a>
              <a
                href="/hamzahafsi-professional-document.pdf"
                target="_blank"
                className="border border-gray-600 text-gray-300 px-8 py-4 rounded-lg font-semibold hover:bg-gray-700 transition-colors flex items-center justify-center gap-2"
              >
                <FileText className="w-5 h-5" /> Document complet
              </a>
            </div>
            <div className="mt-6 text-sm text-gray-400">
              Email : hamza.hafsi.h@gmail.com
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-gray-400 py-8">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <div className="text-lg font-bold text-white mb-2">Projet Atlas</div>
          <div className="text-sm mb-4">
            Automatisation Intelligente des Bilans Carbone : Une Approche Stratégique Multi-Sectorielle
          </div>
          <div className="text-xs">
            © 2025 Hamza Hafsi. Document préparé en Juin 2025 - Version 1.0
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

