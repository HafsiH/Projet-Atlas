import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Button } from '@/components/ui/button.jsx'
import { CheckCircle, ArrowRight } from 'lucide-react'
import Modal from './Modal.jsx'

const PhaseCard = ({ phase, illustration, isReversed = false }) => {
  const [isModalOpen, setIsModalOpen] = useState(false)

  const phaseData = {
    1: {
      number: "1",
      badge: "Phase de découverte",
      badgeColor: "bg-[#1B4332]",
      title: "Découverte et prototype initial",
      description: "Familiarisation avec les processus de bilan carbone et développement du premier modèle IA",
      summary: "Développement d'un modèle de deep learning (v0) spécialisé dans l'analyse textuelle pour l'attribution automatique des codes NACRE. Intégration dans une plateforme web intuitive permettant l'import CSV et l'analyse avec validation utilisateur.",
      highlights: [
        "Modèle de deep learning (v0) pour l'analyse textuelle",
        "Plateforme web intuitive pour l'import CSV",
        "Validation de la pertinence avec les utilisateurs potentiels"
      ],
      fullContent: {
        context: "Cette première phase s'articule autour d'une démarche exploratoire approfondie visant à comprendre les mécanismes fondamentaux de la réalisation des bilans carbone dans l'environnement professionnel contemporain.",
        technical: "Le développement du premier modèle de deep learning (version 0) constitue le cœur technique de cette phase initiale. Ce modèle spécialisé dans l'analyse textuelle avancée a été conçu pour traiter efficacement les libellés comptables complexes.",
        integration: "L'intégration du modèle dans une plateforme web intuitive représente un aspect crucial de la stratégie de déploiement. Cette interface utilisateur a été conçue selon les principes de l'ergonomie moderne.",
        challenges: "Le défi principal identifié réside dans l'identification et la collecte de données de qualité suffisante pour optimiser les performances du modèle."
      }
    },
    2: {
      number: "2",
      badge: "Version professionnelle",
      badgeColor: "bg-[#52796F]",
      title: "Plateforme professionnelle (v1)",
      description: "Amélioration des performances et flux de travail intégré avec visualisations avancées",
      summary: "Amélioration significative des performances du modèle (2-3x supérieure) validée par l'institut INRIA. Création d'une plateforme complète avec flux intégré et visualisations avancées surpassant les outils existants.",
      highlights: [
        "Amélioration 2-3x des performances validée par INRIA",
        "Flux de travail intégré complet",
        "Visualisations avancées avec heat maps et clustering",
        "Publication open source pour adoption organisationnelle"
      ],
      fullContent: {
        validation: "Suite à la validation de la pertinence du prototype par l'institut de recherche INRIA, le développement de la v1 s'articule autour de deux axes majeurs complémentaires.",
        performance: "Le premier axe concerne l'amélioration significative des performances du modèle d'intelligence artificielle, avec un objectif ambitieux de précision deux à trois fois supérieure à la version prototype.",
        platform: "Le second axe majeur porte sur la création d'une plateforme complète offrant un flux de travail intégré et seamless pour les professionnels de la comptabilité carbone.",
        innovation: "L'interface de la version professionnelle proposera des visualisations avancées surpassant qualitativement les outils existants comme labo1point5."
      }
    },
    3: {
      number: "3",
      badge: "Plateforme stratégique",
      badgeColor: "bg-[#10B981]",
      title: "Plateforme stratégique multi-sectorielle",
      description: "Outil d'aide à la décision intégrant les dimensions économiques et environnementales",
      summary: "Transformation en véritable outil d'aide à la décision stratégique dépassant le simple calcul carbone. Intégration des méthodologies financières avec calcul du ROI carbone et outils de risk management.",
      highlights: [
        "Calcul du ROI carbone pour les actions de décarbonation",
        "Intégration native des coûts carbone dans les métriques financières",
        "Outils de risk management avec VaR carbone",
        "Granularité inédite par site, produit ou business unit"
      ],
      fullContent: {
        transformation: "La version finale constitue une évolution paradigmatique vers un véritable outil d'aide à la décision stratégique, dépassant largement le cadre traditionnel du simple calcul carbone.",
        innovation: "L'innovation majeure de cette phase réside dans la transposition intelligente et systématique des méthodologies financières éprouvées au domaine spécifique de la comptabilité carbone.",
        integration: "L'intégration native des coûts carbone dans les métriques financières traditionnelles constitue une innovation méthodologique fondamentale qui transforme radicalement l'approche de la planification stratégique.",
        impact: "Cette approche révolutionnaire transforme fondamentalement le bilan carbone d'une simple obligation réglementaire contraignante en un véritable levier stratégique de création de valeur durable."
      }
    }
  }

  const currentPhase = phaseData[phase]

  return (
    <>
      <Card className="phase-card bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300">
        <div className={`grid md:grid-cols-2 gap-8 ${isReversed ? 'md:grid-flow-col-dense' : ''}`}>
          <div className={`p-8 ${isReversed ? 'md:col-start-2' : ''}`}>
            <div className="flex items-center mb-4">
              <div className={`w-12 h-12 ${currentPhase.badgeColor} rounded-full flex items-center justify-center text-white font-bold text-xl mr-4`}>
                {currentPhase.number}
              </div>
              <Badge className={`${currentPhase.badgeColor} text-white`}>
                {currentPhase.badge}
              </Badge>
            </div>
            
            <CardHeader className="p-0 mb-4">
              <CardTitle className="text-2xl text-gray-900 mb-2">
                {currentPhase.title}
              </CardTitle>
              <CardDescription className="text-gray-600 text-base">
                {currentPhase.description}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="p-0">
              <p className="text-gray-700 mb-6 leading-relaxed">
                {currentPhase.summary}
              </p>
              
              <div className="space-y-3 mb-6">
                {currentPhase.highlights.slice(0, 3).map((highlight, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="text-[#10B981] mr-3 mt-1 flex-shrink-0" size={18} />
                    <p className="text-gray-600 text-sm">{highlight}</p>
                  </div>
                ))}
              </div>
              
              <Button
                onClick={() => setIsModalOpen(true)}
                variant="outline"
                className="border-[#52796F] text-[#52796F] hover:bg-[#52796F] hover:text-white transition-all duration-300"
              >
                Voir les détails
                <ArrowRight className="ml-2" size={16} />
              </Button>
            </CardContent>
          </div>
          
          <div className={`p-8 flex items-center justify-center bg-gray-50 ${isReversed ? 'md:col-start-1' : ''}`}>
            <img 
              src={illustration} 
              alt={`Illustration ${currentPhase.title}`} 
              className="max-w-full h-auto max-h-80 object-contain"
              loading="lazy"
            />
          </div>
        </div>
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={currentPhase.title}
        phase={currentPhase}
      />
    </>
  )
}

export default PhaseCard

