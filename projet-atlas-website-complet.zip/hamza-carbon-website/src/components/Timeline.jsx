import React from 'react'
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Dot } from 'recharts'

const Timeline = () => {
  const timelineData = [
    {
      phase: 'Phase 1',
      name: 'Découverte',
      progress: 25,
      maturity: 30,
      description: 'Prototype initial et validation concept'
    },
    {
      phase: 'Phase 2',
      name: 'Professionnelle',
      progress: 65,
      maturity: 70,
      description: 'Plateforme intégrée et performances optimisées'
    },
    {
      phase: 'Phase 3',
      name: 'Stratégique',
      progress: 100,
      maturity: 100,
      description: 'Solution complète et déploiement multi-sectoriel'
    }
  ]

  const CustomDot = (props) => {
    const { cx, cy, payload } = props
    return (
      <g>
        <Dot 
          cx={cx} 
          cy={cy} 
          r={8} 
          fill="#1B4332" 
          stroke="#fff" 
          strokeWidth={3}
        />
        <circle 
          cx={cx} 
          cy={cy} 
          r={12} 
          fill="none" 
          stroke="#1B4332" 
          strokeWidth={2} 
          opacity={0.3}
        />
      </g>
    )
  }

  return (
    <div className="bg-white rounded-2xl p-8 shadow-lg">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">
          Évolution du projet
        </h3>
        <p className="text-gray-600">
          Progression de la maturité technologique et de l'impact stratégique
        </p>
      </div>

      {/* Timeline graphique */}
      <div className="h-64 mb-8">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={timelineData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <XAxis 
              dataKey="name" 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 14, fill: '#6B7280' }}
            />
            <YAxis 
              domain={[0, 100]}
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6B7280' }}
              label={{ value: 'Maturité (%)', angle: -90, position: 'insideLeft' }}
            />
            <Line
              type="monotone"
              dataKey="maturity"
              stroke="url(#timelineGradient)"
              strokeWidth={4}
              dot={<CustomDot />}
              activeDot={{ r: 10, fill: '#10B981' }}
            />
            <defs>
              <linearGradient id="timelineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#1B4332" />
                <stop offset="50%" stopColor="#52796F" />
                <stop offset="100%" stopColor="#F56500" />
              </linearGradient>
            </defs>
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Timeline détaillée */}
      <div className="space-y-6">
        {timelineData.map((item, index) => (
          <div key={index} className="flex items-start">
            <div className="flex-shrink-0 mr-6">
              <div className="w-12 h-12 bg-gradient-to-r from-[#1B4332] to-[#52796F] rounded-full flex items-center justify-center text-white font-bold">
                {index + 1}
              </div>
            </div>
            <div className="flex-grow">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-lg font-semibold text-gray-900">{item.name}</h4>
                <span className="text-sm font-medium text-[#10B981]">{item.maturity}% maturité</span>
              </div>
              <p className="text-gray-600 mb-3">{item.description}</p>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-[#1B4332] to-[#10B981] h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${item.progress}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Timeline

