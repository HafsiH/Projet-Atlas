import React from 'react'
import { Button } from '@/components/ui/button.jsx'
import { ArrowRight, ChevronDown } from 'lucide-react'

const Hero = () => {
  const scrollToSection = (sectionId) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Dégradé SVG animé */}
      <div className="absolute inset-0">
        <svg className="w-full h-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id="heroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1B4332">
                <animate attributeName="stop-color" 
                  values="#1B4332;#2d5a47;#1B4332" 
                  dur="8s" 
                  repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#52796F">
                <animate attributeName="stop-color" 
                  values="#52796F;#6b8a7a;#52796F" 
                  dur="8s" 
                  repeatCount="indefinite" />
              </stop>
            </linearGradient>
            
            {/* Formes géométriques animées */}
            <circle id="circle1" cx="200" cy="150" r="120" fill="rgba(255,255,255,0.1)">
              <animateTransform attributeName="transform" 
                type="translate" 
                values="0,0;50,30;0,0" 
                dur="12s" 
                repeatCount="indefinite" />
            </circle>
            
            <circle id="circle2" cx="1000" cy="600" r="80" fill="rgba(255,255,255,0.05)">
              <animateTransform attributeName="transform" 
                type="translate" 
                values="0,0;-30,20;0,0" 
                dur="10s" 
                repeatCount="indefinite" />
            </circle>
            
            <polygon points="800,100 900,200 700,200" fill="rgba(255,255,255,0.08)">
              <animateTransform attributeName="transform" 
                type="rotate" 
                values="0 800 150;360 800 150" 
                dur="20s" 
                repeatCount="indefinite" />
            </polygon>
          </defs>
          
          <rect width="100%" height="100%" fill="url(#heroGradient)" />
          <use href="#circle1" />
          <use href="#circle2" />
          <use href="#polygon1" />
        </svg>
      </div>

      {/* Overlay pour améliorer la lisibilité */}
      <div className="absolute inset-0 bg-black/20"></div>

      {/* Contenu principal */}
      <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="animate-fade-in-up">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Automatisation
            <span className="block text-[#10B981] mt-2">Carbone Intelligente</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-4xl mx-auto leading-relaxed">
            Révolutionner la comptabilité carbone grâce à l'automatisation intelligente 
            et aux plateformes de prise de décision stratégique
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => scrollToSection('about')}
              className="bg-[#10B981] hover:bg-[#059669] text-white px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Voir la démo
              <ArrowRight className="ml-2" size={20} />
            </Button>
            <Button 
              onClick={() => scrollToSection('phases')}
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-[#1B4332] px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300"
            >
              Découvrir les phases
            </Button>
          </div>
        </div>
      </div>
      
      {/* Indicateur de scroll animé */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white">
        <div className="animate-bounce">
          <ChevronDown size={32} className="opacity-80" />
        </div>
        <p className="text-sm mt-2 opacity-70">Défiler pour explorer</p>
      </div>
    </section>
  )
}

export default Hero

