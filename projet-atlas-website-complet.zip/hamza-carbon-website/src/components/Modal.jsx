import React, { useEffect } from 'react'
import { X, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'

const Modal = ({ isOpen, onClose, title, phase }) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }

    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [isOpen])

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener('keydown', handleEscape)
    }

    return () => {
      document.removeEventListener('keydown', handleEscape)
    }
  }, [isOpen, onClose])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 rounded-t-2xl">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600 transition-colors p-2 rounded-full hover:bg-gray-100"
                aria-label="Fermer"
              >
                <X size={24} />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="px-6 py-6">
            {/* Description */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Description</h3>
              <p className="text-gray-700 leading-relaxed">{phase.description}</p>
            </div>

            {/* Highlights */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Points clés</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {phase.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="text-[#10B981] mr-3 mt-1 flex-shrink-0" size={20} />
                    <p className="text-gray-600">{highlight}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Detailed Content */}
            <div className="space-y-6">
              {Object.entries(phase.fullContent).map(([key, content], index) => (
                <div key={key} className="bg-gray-50 rounded-lg p-6">
                  <h4 className="text-md font-semibold text-gray-900 mb-3 capitalize">
                    {key === 'context' && 'Contexte et enjeux'}
                    {key === 'technical' && 'Architecture technique'}
                    {key === 'integration' && 'Intégration plateforme'}
                    {key === 'challenges' && 'Défis identifiés'}
                    {key === 'validation' && 'Validation institutionnelle'}
                    {key === 'performance' && 'Amélioration des performances'}
                    {key === 'platform' && 'Plateforme intégrée'}
                    {key === 'innovation' && 'Innovation méthodologique'}
                    {key === 'transformation' && 'Transformation stratégique'}
                    {key === 'impact' && 'Impact et création de valeur'}
                  </h4>
                  <p className="text-gray-700 leading-relaxed">{content}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 rounded-b-2xl">
            <div className="flex justify-end">
              <Button
                onClick={onClose}
                className="bg-[#1B4332] hover:bg-[#2d5a47] text-white px-6 py-2"
              >
                Fermer
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Modal

