import React, { useState, useEffect, useRef } from 'react'
import { TrendingUp, Target, BarChart3, Zap } from 'lucide-react'

const KPIWidget = () => {
  const [isVisible, setIsVisible] = useState(false)
  const [animatedValues, setAnimatedValues] = useState({
    co2Reduction: 0,
    timeReduction: 0,
    precision: 0,
    organizations: 0
  })
  
  const ref = useRef()

  const targetValues = {
    co2Reduction: 85, // % de CO2 économisé simulé
    timeReduction: 90, // % de réduction du temps
    precision: 300, // % d'amélioration de précision
    organizations: 150 // nombre d'organisations potentielles
  }

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true)
        }
      },
      { threshold: 0.3 }
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [isVisible])

  useEffect(() => {
    if (!isVisible) return

    const duration = 2000 // 2 secondes
    const steps = 60
    const stepDuration = duration / steps

    let currentStep = 0

    const timer = setInterval(() => {
      currentStep++
      const progress = currentStep / steps

      setAnimatedValues({
        co2Reduction: Math.floor(targetValues.co2Reduction * progress),
        timeReduction: Math.floor(targetValues.timeReduction * progress),
        precision: Math.floor(targetValues.precision * progress),
        organizations: Math.floor(targetValues.organizations * progress)
      })

      if (currentStep >= steps) {
        clearInterval(timer)
      }
    }, stepDuration)

    return () => clearInterval(timer)
  }, [isVisible])

  const kpis = [
    {
      icon: TrendingUp,
      label: "Réduction CO₂",
      value: animatedValues.co2Reduction,
      suffix: "%",
      color: "text-[#10B981]",
      bgColor: "bg-[#10B981]/10",
      description: "Économies carbone simulées"
    },
    {
      icon: Zap,
      label: "Gain de temps",
      value: animatedValues.timeReduction,
      suffix: "%",
      color: "text-[#F56500]",
      bgColor: "bg-[#F56500]/10",
      description: "Réduction temps de traitement"
    },
    {
      icon: Target,
      label: "Précision",
      value: animatedValues.precision,
      suffix: "%",
      color: "text-[#1B4332]",
      bgColor: "bg-[#1B4332]/10",
      description: "Amélioration de la précision"
    },
    {
      icon: BarChart3,
      label: "Organisations",
      value: animatedValues.organizations,
      suffix: "+",
      color: "text-[#52796F]",
      bgColor: "bg-[#52796F]/10",
      description: "Adoptions potentielles"
    }
  ]

  return (
    <div ref={ref} className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {kpis.map((kpi, index) => {
        const Icon = kpi.icon
        return (
          <div
            key={index}
            className={`${kpi.bgColor} rounded-2xl p-6 text-center transition-all duration-500 hover:scale-105 hover:shadow-lg`}
            style={{
              animationDelay: `${index * 200}ms`
            }}
          >
            <div className={`w-16 h-16 ${kpi.bgColor} rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-white shadow-lg`}>
              <Icon className={kpi.color} size={28} />
            </div>
            
            <div className="mb-2">
              <span className={`text-3xl font-bold ${kpi.color}`}>
                {kpi.value}
              </span>
              <span className={`text-xl font-semibold ${kpi.color}`}>
                {kpi.suffix}
              </span>
            </div>
            
            <h4 className="font-semibold text-gray-900 mb-1">
              {kpi.label}
            </h4>
            
            <p className="text-sm text-gray-600">
              {kpi.description}
            </p>
          </div>
        )
      })}
    </div>
  )
}

export default KPIWidget

