import React, { useState, useEffect } from 'react'
import { Menu, X, ChevronRight } from 'lucide-react'

const Layout = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('hero')
  const [showTOC, setShowTOC] = useState(false)

  const sections = [
    { id: 'hero', label: 'Accueil' },
    { id: 'about', label: 'À propos' },
    { id: 'phases', label: 'Phases du projet' },
    { id: 'impact', label: 'Impact stratégique' },
    { id: 'contact', label: 'Contact' }
  ]

  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: '-20% 0px -80% 0px',
      threshold: 0
    }

    const observerCallback = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id)
        }
      })
    }

    const observer = new IntersectionObserver(observerCallback, observerOptions)

    sections.forEach(({ id }) => {
      const element = document.getElementById(id)
      if (element) observer.observe(element)
    })

    return () => observer.disconnect()
  }, [])

  const scrollToSection = (sectionId) => {
    document.getElementById(sectionId)?.scrollIntoView({ 
      behavior: 'smooth',
      block: 'start'
    })
    setIsMenuOpen(false)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar sticky avec backdrop blur */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-md border-b border-gray-200 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <button 
                onClick={() => scrollToSection('hero')}
                className="text-2xl font-bold text-gradient hover:opacity-80 transition-opacity"
              >
                Hamza Hafsi
              </button>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                {sections.slice(1).map(({ id, label }) => (
                  <button
                    key={id}
                    onClick={() => scrollToSection(id)}
                    className={`transition-colors duration-200 ${
                      activeSection === id
                        ? 'text-[#1B4332] font-semibold border-b-2 border-[#1B4332]'
                        : 'text-gray-700 hover:text-[#1B4332]'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-700 hover:text-[#1B4332] transition-colors"
                aria-label="Menu de navigation"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200 shadow-lg">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {sections.slice(1).map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => scrollToSection(id)}
                  className={`block w-full text-left px-3 py-2 rounded-md transition-colors ${
                    activeSection === id
                      ? 'text-[#1B4332] bg-gray-100 font-semibold'
                      : 'text-gray-700 hover:text-[#1B4332] hover:bg-gray-50'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Table of contents latéral pour desktop */}
      <div className="hidden xl:block fixed left-6 top-1/2 transform -translate-y-1/2 z-40">
        <div className={`transition-all duration-300 ${showTOC ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="bg-white/95 backdrop-blur-md rounded-lg shadow-lg border border-gray-200 p-4 w-64">
            <h3 className="font-semibold text-gray-900 mb-3">Table des matières</h3>
            <nav className="space-y-2">
              {sections.map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => scrollToSection(id)}
                  className={`flex items-center w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                    activeSection === id
                      ? 'text-[#1B4332] bg-[#1B4332]/10 font-medium'
                      : 'text-gray-600 hover:text-[#1B4332] hover:bg-gray-50'
                  }`}
                >
                  <ChevronRight size={16} className="mr-2" />
                  {label}
                </button>
              ))}
            </nav>
          </div>
        </div>
        
        {/* Toggle button pour TOC */}
        <button
          onClick={() => setShowTOC(!showTOC)}
          className="absolute -right-12 top-4 bg-[#1B4332] text-white p-2 rounded-r-lg shadow-lg hover:bg-[#2d5a47] transition-colors"
          aria-label="Table des matières"
        >
          <Menu size={20} />
        </button>
      </div>

      {/* Contenu principal */}
      <main className="pt-16">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Hamza Hafsi</h3>
            <p className="text-gray-400 mb-6">
              Automatisation Intelligente des Bilans Carbone : Une Approche Stratégique Multi-Sectorielle
            </p>
            <div className="border-t border-gray-800 pt-6">
              <p className="text-gray-500">
                © 2025 Hamza Hafsi. Document préparé en Juin 2025 - Version 1.0
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default Layout

